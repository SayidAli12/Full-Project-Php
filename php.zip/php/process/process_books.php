<?php 
session_start();

// Include the connection file (make sure the filename and path are correct)
include('../Conection.php');
if (isset ($_POST['save']) ) {
	$book_name = $_POST['book_name'];
	$edition = $_POST['edition'];
	$category = $_POST['category'];
	$page = $_POST['page'];
	$qty = $_POST['qty'];

//save query
	$mysqli->query("
		INSERT INTO books
		( book_name , edition , category ,  page , qty)
		VALUES 
       ('$book_name', '$edition' , '$category' ,  '$page' , '$qty')
		")
	or die (mysqli_error($mysqli));
	$_SESSION['save_msg'] = "Saved Successfully";
	header("location: ../view_books.php");
	
}
if (isset ($_POST['update']) ) {
	$id = $_POST['id'];
	$book_name = $_POST['book_name'];
	$edition = $_POST['edition'];
	$category= $_POST['category'];
	$page = $_POST['page'];
	$qty = $_POST['qty'];

//update query
	$mysqli->query("
		UPDATE books
		SET 
		book_name = '$book_name',
	    edition = '$edition',
		category = '$category',
		page = '$page',
		qty = '$qty'
      WHERE 
      id = '$id'
		")
	or die (mysqli_error($mysqli));
	 $_SESSION['update_msg'] = 'Updated Successfully';
	header("location: ../view_books.php");
}
if ($_GET['delete']){

$id =$_GET ['delete'];
$mysqli->query("
DELETE FROM  books
WHERE 
id ='$id'
	")
 or die(mysqli_error($mysqli));
 $_SESSION['delete_msg'] ='Deleted Successfully';
header("location: ../view_books.php");
}

 ?>