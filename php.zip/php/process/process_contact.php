<?php 
session_start();

// Include the connection file (make sure the filename and path are correct)
include('../Conection.php');
if (isset ($_POST['send']) ) {
	$your_name = $_POST['your_name'];
	$your_email = $_POST['your_email'];
	$your_massage = $_POST['your_massage'];

//save query
	$mysqli->query("
		INSERT INTO contact
		(your_name, your_email, your_massage )
		VALUES 
		('$your_name', '$your_email',  '$your_massage' )

		")
	or die (mysqli_error($mysqli));
	$_SESSION['save_msg'] = "Saved Successfully";
	header("location: ../contact.php");
	
}
if (isset ($_POST['update']) ) {
	$id = $_POST['id'];
	$your_name = $_POST['your_name'];
	$your_email= $_POST['your_email'];
	$your_massage = $_POST['your_massage'];

	}
	if ($_GET['delete']){

$id =$_GET ['delete'];
$mysqli->query("
DELETE FROM contact
WHERE 
id ='$id'
	")
 or die(mysqli_error($mysqli));
 
 $_SESSION['delete_msg'] ='Deleted Successfully';
header("location: ../view_feedback.php");

}

 ?>