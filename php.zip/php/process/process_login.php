<?php
session_start();

// Include the connection file (make sure the filename and path are correct)
include('../Conection.php');

// Check if the form is submitted
if (isset($_POST['login'])) {
    if (empty($_POST['username']) || empty($_POST['password'])) {
        $_SESSION['empty'] = "Please fill username and password fields";
        header('Location: ../login.php');
        exit();
    } else {
        // Get the username and password from the POST request
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        // Create a prepared statement to prevent SQL injection
        $stmt = $mysqli->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_array();

        if ($row) {
            $_SESSION['user_id'] = $row["id"];
            $_SESSION['username'] = $row["username"];
            $_SESSION['full_name'] = $row["full_name"];
            $_SESSION['role'] = $row["role"];
            header('Location: ../index.php');
        } else {
            $_SESSION['incorrect_login'] = "Incorrect Username Or Password";
            header('Location: ../login.php');
        }
        
        // Close the prepared statement
        $stmt->close();
    }
}

// Close the database connection
$mysqli->close();
?>
