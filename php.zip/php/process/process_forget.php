<?php
session_start();

// Include the connection file (make sure the filename and path are correct)
include('../Conection.php');
// Check if form is submitted
if(isset($_POST['Update_Pass'])) {
    if (!isset($_POST['username'])) {
        $_POST['incorrect'] = 'Username not set in session!';
        header('location: ../forget.php');
        exit();
    }

    $username = $_POST['username'];
    
    // Check if full name exists
    $result = $mysqli->query("
        SELECT username FROM users WHERE username = '$username'
    ") or die($mysqli->error);

    if($result->num_rows > 0) {
        $_SESSION['old_username'] = $username;
        $_SESSION['Changed'] = "Password Successfully Changed";
        header("location: ../Update_Pass.php");
    } else {
        $_SESSION['incorrect'] = 'Full Name does not exist!';
        header('location: ../forget.php');
    }
    exit(); // Ensure no further code is executed after the redirect
}
?>
