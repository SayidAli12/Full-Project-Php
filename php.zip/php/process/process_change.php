<?php 
session_start();

// Include the connection file (make sure the filename and path are correct)
include('../Conection.php');     
 if(isset($_POST['change_pass']));
 {
      $old_pass = $_POST['old_pass'];
      $new_pass = $_POST['new_pass'];
      $username = $_SESSION['username'];

// confirm old pass
$result = $mysqli->query("
      SELECT password from users 
      where
      username='$username'
      and 
      password='$old_pass'
            ")
or die (mysql_error($mysqli));

$row = $result->fetch_array();
if($row){
      $mysqli->query("
      UPDATE users
      set 
      password = '$new_pass'
      where
      username ='$username'
            ") 
      
      or die (mysqli_error($mysqli));
     $_SESSION['Changed'] = "Password Succesfully Changed";
      header("location: ../change_password.php");
} else{
      $_SESSION['incorrect'] = 'incorrect Old Passwod!';
      header('location:../change_password.php');
}
}
?>