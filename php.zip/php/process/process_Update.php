<?php 
session_start();

// Include the connection file (make sure the filename and path are correct)
include('../Conection.php');

if(isset($_POST['update']));
 {
      $new_pass = $_POST['new_pass'];
      $username = $_SESSION['old_username'];

// confirm old pass
$result = $mysqli->query("
      UPDATE users
      set 
      password = '$new_pass'
      where
      username ='$username'
            ")      
      or die (mysqli_error($mysqli));
     $_SESSION['Changed'] = "Password Succesfully Changed";
      header("location: ../login.php");
}

?>