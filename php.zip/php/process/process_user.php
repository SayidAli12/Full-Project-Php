<?php 
session_start();

// Include the connection file (make sure the filename and path are correct)
include('../Conection.php');
if (isset ($_POST['save']) ) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	$full_name = $_POST['full_name'];
	$role = $_POST['role'];

	

//save query
	$mysqli->query("
		INSERT INTO users
		(username, password, role , full_name )
		VALUES 
		('$username', '$password', '$role' , '$full_name' )

		")
	or die (mysqli_error($mysqli));
	$_SESSION['save_msg'] = "Saved Successfully";
	header("location: ../view_user.php");
	
}


if (isset ($_POST['update']) ) {
	$user_id = $_POST['user_id'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$full_name = $_POST['full_name'];
	$role = $_POST['role'];

//update query
	$mysqli->query("
		UPDATE users
		SET 
		username = '$username',
		password = '$password',
		full_name = '$full_name',
		role = '$role'
      WHERE 
      user_id = '$user_id'
		")
	or die (mysqli_error($mysqli));
	  $_SESSION['update_msg'] = 'Updated Successfully';
	header("location: ../view_user.php");
}

if ($_GET['delete']){

$user_id =$_GET ['delete'];
$mysqli->query("
DELETE FROM  users
WHERE 
user_id ='$user_id'
	")
 or die(mysqli_error($mysqli));
 $_SESSION['delete_msg'] ='Deleted Successfully';

header("location: ../view_user.php");
}
 ?>