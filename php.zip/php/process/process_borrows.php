<?php 
session_start();

// Include the connection file (make sure the filename and path are correct)
include('../Conection.php');
 if (isset($_POST['save'])) {
    $Student_id = $_POST['Student_id'];
    $book_id = $_POST['book_id'];
    $time = $_POST['time'];
    $date = $_POST['date'];

    // Check if the book is available
    $book_query = $mysqli->query("SELECT `qty` FROM `books` WHERE `id` = '$book_id'");
    $book_data = $book_query->fetch_assoc();
    $book_qty = $book_data['qty'];

    if ($book_qty > 0) { // If the book is available
        // Save borrow record
        $mysqli->query("
            INSERT INTO borrows
            (Student_id, book_id, time, date)
            VALUES 
            ('$Student_id', '$book_id', '$time', '$date')
        ") or die(mysqli_error($mysqli));
        
        // Update book quantity
        $new_qty = $book_qty - 1;
        $mysqli->query("
            UPDATE `books` SET `qty` = '$new_qty' WHERE `id` = '$book_id'
        ") or die(mysqli_error($mysqli));

        $_SESSION['save_msg'] = "Saved Successfully";
    } else {
        $_SESSION['error_msg'] = "Book not available.";
    }

    header("location: ../view_borrows.php");
}


if (isset($_GET['return'])) {
    $borrow_id = $_GET['return'];

    // Update the status to 'returned' in the database
    $return_query = "UPDATE borrows SET status = 'returned' WHERE id = $borrow_id";

    if ($mysqli->query($return_query) === TRUE) {
        $_SESSION['update_msg'] = "Book returned successfully!";
    } else {
        $_SESSION['error_msg'] = "Error returning book: " . $mysqli->error;
    }


    $_SESSION['update_msg'] = 'Updated Successfully';
    header("location: ../view_borrows.php");
}





if (isset($_GET['Returned'])) {
    // Validate and sanitize the ID
    $id = filter_var($_GET['Returned'], FILTER_VALIDATE_INT);
    if ($id === false) {
        // Invalid ID, redirect with error message
        $_SESSION['delete_msg'] = 'Invalid ID';
        header("location: ../view_borrows.php");
        exit; // Stop further execution
    }

    // Get the current date
    $currentDate = date('Y-m-d');

    // Update the status and date in the database
    $sql = "UPDATE borrows SET status = 'returned', date = '$currentDate' WHERE id = '$id'";
    $result = $mysqli->query($sql);

    // Check if the query was successful
    if ($result) {
        // Update successful, set success message
        $_SESSION['delete_msg'] = 'Updated Status Successfully';

    // Redirect to the view_borrows.php page
    header("location: ../view_borrows.php");
    exit; // Stop further execution
    } else {
        // Update failed, set error message
        $_SESSION['delete_msg'] = 'Error updating status: ' . $mysqli->error;
        
    // Redirect to the view_borrows.php page
    header("location: ../view_borrows.php");
    exit; // Stop further execution
    }

    // Close database connection
    $mysqli->close();

}



if ($_GET['delete']){

$id =$_GET ['delete'];
$mysqli->query("
DELETE FROM  borrows
WHERE 
id ='$id'
	")
 or die(mysqli_error($mysqli));
 $_SESSION['delete_msg'] ='Deleted Successfully';

header("location: ../view_borrows.php");
}

 ?>