<style type="text/css">
   html {
  position: relative;
  min-height: 100%;
}
body {
  margin-bottom: 60px;
}
.footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 60px;
 background-image: url(D.png); 
}
 </style>
 
<br>


<div class="footer navbar-fixed-bottom">

</div>
  
</body>
</html>