-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2024 at 08:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `book_name` varchar(200) NOT NULL,
  `edition` varchar(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `page` varchar(200) NOT NULL,
  `qty` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `book_name`, `edition`, `category`, `page`, `qty`) VALUES
(21, 'Carabi', '2014 ', 'Arabi ', '23 ', 60),
(24, 'Tenry', '2013 ', 'History ', '13 ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `borrows`
--

CREATE TABLE `borrows` (
  `id` int(11) NOT NULL,
  `Student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `time` date NOT NULL,
  `date` date NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrows`
--

INSERT INTO `borrows` (`id`, `Student_id`, `book_id`, `time`, `date`, `status`) VALUES
(75, 18, 21, '2024-04-29', '2024-05-24', 'returned'),
(77, 18, 21, '2024-05-31', '2024-06-06', 'returned'),
(81, 27, 21, '2024-06-10', '2024-06-11', 'unreturned'),
(85, 27, 21, '2024-06-04', '2024-06-18', 'returned'),
(87, 38, 21, '2024-06-23', '2024-06-24', 'Pending'),
(88, 17, 21, '2024-06-23', '2024-06-26', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `your_name` varchar(22) NOT NULL,
  `your_email` varchar(22) NOT NULL,
  `your_massage` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `your_name`, `your_email`, `your_massage`) VALUES
(3, 'SayidAli', 'Suldaanzayidali@gmail.', 'wertyui'),
(4, 'SayidAli', 'Suldaanzayidali@gmail.', 'yuugddg'),
(5, 'SayidAli', 'suldaanzayidali@gmail.', ''),
(6, 'SayidAli', 'suldaanzayidali@gmail.', '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contact` varchar(200) NOT NULL,
  `Faculty` varchar(200) NOT NULL,
  `semester` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_name`, `gender`, `address`, `contact`, `Faculty`, `semester`) VALUES
(17, 'Zayid Ali', 'Male', 'Burao    ', '633333334  ', 'HRM', 'Semester Eight'),
(18, 'Ali', 'Female', 'Burao     ', '633124345     ', 'Social Science', 'semester Seven'),
(19, 'Zayid ', 'Male', 'Burao   ', '6345124345   ', 'ICT', 'Semester Six'),
(27, 'SayidAli', 'Female', 'Mohali       ', '4352567           ', 'ICT', 'semester Two'),
(29, 'Xamda  Ali', 'Female', 'Burao  ', '25263333336   ', 'Accounting', 'semester Three'),
(32, 'abdiaziz', 'Male', 'burao  ', '0634343434  ', 'ICT', 'semester Fifth'),
(33, 'abdiaziz', 'Male', 'burao           ', '0634433221           ', 'Social Science', 'Semester Four'),
(38, 'Mohamed Farah', 'Male', 'mohali ', '45678 ', 'HRM', 'Semeter Four'),
(41, 'Ahmed Abdi Jama', 'Male', 'burao', '67667', 'HRM', 'Sem Two');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `role`) VALUES
(1, 'Admin', '12', 'Zayid Ali ', 'Admin'),
(7, 'Ahmed', '123', 'Ahmed Abdi Jama', 'User'),
(8, 'Khalid', '234  ', 'Khalid Ahmed          ', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `borrows`
--
ALTER TABLE `borrows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Student_id` (`Student_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `borrows`
--
ALTER TABLE `borrows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrows`
--
ALTER TABLE `borrows`
  ADD CONSTRAINT `Student_id` FOREIGN KEY (`Student_id`) REFERENCES `students` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
