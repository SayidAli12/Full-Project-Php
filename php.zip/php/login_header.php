<?php session_start(); ?>


<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="css/select2.min.css">
 <link rel="stylesheet" type="text/css" href="assets\fontawesome-free-6.5.1-web\css\all.min.css">
<link rel="stylesheet" type="text/css" href="assets\fontawesome-free-6.5.1-web\css\fontawesome.min.css">

<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/select2.min.js"></script>
<link rel="stylesheet" type="text/css" href="assests/datetimepicker/jquery.datetimepicker.css">
<script type="assests/datetimepicker/build/jquery.datetimepicker.full.min.js"></script>
</head>
<body>
<style>
body {
  background-image: url('D.png');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
</style>
</body>